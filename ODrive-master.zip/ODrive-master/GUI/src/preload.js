import { ipcRenderer } from 'electron'
window.ipcRenderer = ipcRenderer