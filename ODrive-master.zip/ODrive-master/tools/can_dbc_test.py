import math
import can
import cantools
import time

database = cantools.db.load_file("C:/Users/LEC/Desktop/Test brushless/odrive-master/tools/odrive-cansimple.dbc")
bus = can.Bus("COM18", bustype="slcan")
axisID = 1
round = 360 

d = 10  # Length between origin and the two motors
l1 = 10.0  # Length from motor to passive joints
l2 = 10.0  # Length from passive joints to end effector
l3 = 15
l4 = 15
r = 360

 #PID 
msg = database.get_message_by_name('Axis0_Set_Vel_Gains')
data = database.encode_message('Axis0_Set_Vel_Gains', {'Vel_Integrator_Gain':0.166, 'Vel_Gain':0.125})
msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
bus.send(msg)

msg = database.get_message_by_name('Axis0_Set_Pos_Gain')
data = database.encode_message('Axis0_Set_Pos_Gain', {'Pos_Gain':5.0})
msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
bus.send(msg)

# Equation inverse kinematic

def calc_angles(x, y):
    a1 = math.sqrt((x + d/2)**2 + y**2)
    a2 = math.sqrt((x - d/2)**2 + y**2)

    alpha1 = math.atan2(y, x + d/2)
    alpha2 = math.atan2(y, x - d/2)

    b1 = (l1**2 + a1**2 - l3**2) / (2 * l1 * a1)
    beta1 = math.acos(b1)

    b2 = (l2**2 + a2**2 - l4**2) / (2 * l2 * a2)
    beta2 = math.acos(b2)

    #theta1 = (alpha1 + beta1) *180/math.pi #mode ++
    #theta2 = (alpha2 + beta2) *180/math.pi #mode ++
    theta1 = (alpha1 + beta1) *180/math.pi #mode +-
    theta2 = (alpha2 + beta2) *180/math.pi #mode +-
    #theta1 = (alpha1 - beta1) *180/math.pi #mode --
    #theta2 = (alpha2 - beta2) *180/math.pi #mode --
    return (theta1, theta2)
t = 0.0
T = 0.5
f = 1/T
w = 2*math.pi*f

try:
# # config closeloop first
    while True:

        x = 5*math.cos(w*t)
        y = 5*math.sin(w*t)+15
        shoulder = calc_angles(x, y)
        print(shoulder)

        theta1 = shoulder[0]  # Extract the x-coordinate from the shoulder angles
        theta2 = shoulder[1]  # Extract the y-coordinate from the shoulder angles

        msg = database.get_message_by_name('Axis0_Set_Input_Pos')
# step1.'Input_Pos': 1 = 1 round, step2. Input_Pos': 0 = again
        data = database.encode_message('Axis0_Set_Input_Pos', {'Input_Pos': theta2/r, 'Vel_FF':0.0, 'Torque_FF':0.0})
        msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
        print(database.decode_message('Axis0_Set_Input_Pos', msg.data))
        print(msg)

        t = t+.01
        bus.send(msg)
        time.sleep(0.00001)
        print("Message sent on {}".format(bus.channel_info))
except can.CanError:
    print("Message NOT sent!  Please verify can0 is working first")

#.............................................................................................

# import math
# import can
# import cantools
# import time
# import matplotlib.pyplot as plt

# database = cantools.db.load_file("C:/Users/LEC/Desktop/Test brushless/odrive-master/tools/odrive-cansimple.dbc")
# bus = can.Bus("COM18", bustype="slcan")
# axisID = 1
# round = 360 

# d = 10  # Length between origin and the two motors
# l1 = 10.0  # Length from motor to passive joints
# l2 = 10.0  # Length from passive joints to end effector
# l3 = 15
# l4 = 15
# r = 360

# # PID 
# msg = database.get_message_by_name('Axis0_Set_Vel_Gains')
# data = database.encode_message('Axis0_Set_Vel_Gains', {'Vel_Integrator_Gain':0.166, 'Vel_Gain':0.125})
# msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
# bus.send(msg)

# msg = database.get_message_by_name('Axis0_Set_Pos_Gain')
# data = database.encode_message('Axis0_Set_Pos_Gain', {'Pos_Gain':5.0})
# msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
# bus.send(msg)

# # Equation inverse kinematic

# def calc_angles(x, y):
#     a1 = math.sqrt((x + d/2)**2 + y**2)
#     a2 = math.sqrt((x - d/2)**2 + y**2)

#     alpha1 = math.atan2(y, x + d/2)
#     alpha2 = math.atan2(y, x - d/2)

#     b1 = (l1**2 + a1**2 - l3**2) / (2 * l1 * a1)
#     beta1 = math.acos(b1)

#     b2 = (l2**2 + a2**2 - l4**2) / (2 * l2 * a2)
#     beta2 = math.acos(b2)

#     #theta1 = (alpha1 + beta1) *180/math.pi #mode ++
#     #theta2 = (alpha2 + beta2) *180/math.pi #mode ++
#     theta1 = (alpha1 + beta1) *180/math.pi #mode +-
#     theta2 = (alpha2 - beta2) *180/math.pi #mode +-
#     #theta1 = (alpha1 - beta1) *180/math.pi #mode --
#     #theta2 = (alpha2 - beta2) *180/math.pi #mode --
#     return (theta1, theta2)
# t = 0.0
# T = 0.5
# f = 1/T
# w = 2*math.pi*f

# try:
# # # config closeloop first
#     while True:

#         x = 5*math.cos(w*t)
#         y = 5*math.sin(w*t)+15
#         shoulder = calc_angles(x, y)
#         print(shoulder)

#         theta1 = shoulder[0]  # Extract the x-coordinate from the shoulder angles
#         theta2 = shoulder[1]  # Extract the y-coordinate from the shoulder angles

#         msg = database.get_message_by_name('Axis0_Set_Input_Pos')
#         data = database.encode_message('Axis0_Set_Input_Pos', {'Input_Pos': theta1/r, 'Vel_FF':0.0, 'Torque_FF':0.0})
#         msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
#         print(database.decode_message('Axis0_Set_Input_Pos', msg.data))
#         print(msg)

#         t = t+.01
#         bus.send(msg)
#         time.sleep(0.01)
#         print("Message sent on {}".format(bus.channel_info))

#         # Store the shoulder angles and time for plotting
#         theta1.append(theta1)
#         theta2.append(theta2)
#         t.append(t)

# except can.CanError:
#     print("Message NOT sent!  Please verify can0 is working first")

# # Plot the shoulder angles
# plt.figure(figsize=(12, 6))
# plt.plot(t, theta1, label='Theta1')
# plt.plot(t, theta2, label='Theta2')
# plt.xlabel('Time (s)')
# plt.ylabel('Angle (degrees)')
# plt.title('Shoulder Angles Over Time')
# plt.legend()
# plt.grid()
# plt.show()