import math
import can
import cantools
import time

database = cantools.db.load_file("C:/Users/LEC/Desktop/Test brushless/odrive-master/tools/odrive-cansimple.dbc")


bus = can.Bus("COM18", bustype="slcan")
axisID = 1
round = 360

# print("\nRequesting AXIS_STATE_FULL_CALIBRATION_SEQUENCE (0x007) on axisID: " + str(axisID))
# msg = database.get_message_by_name('Axis0_Set_Axis_State')
# #step1.'Axis_Requested_State':4.0, step2. 'Axis_Requested_State':7.0, step3.closeloop 'Axis_Requested_State':8.0
# data = database.encode_message('Axis0_Set_Axis_State', {'Axis_Requested_State':8.0})
# msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
# print(database.decode_message('Axis0_Set_Axis_State', msg.data))
# print(msg)
# bus.send(msg)


        # Test motor first
# msg = database.get_message_by_name('Axis0_Set_Input_Pos')
# # step1.'Input_Pos': 1 = 1 round, step2. Input_Pos': 0 = again
# data = database.encode_message('Axis0_Set_Input_Pos', {'Input_Pos':0, 'Vel_FF':0.0, 'Torque_FF':0.0})
# msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
# print(database.decode_message('Axis0_Set_Input_Pos', msg.data))
# print(msg)
# bus.send(msg)


#         # PID 
msg = database.get_message_by_name('Axis0_Set_Vel_Gains')
data = database.encode_message('Axis0_Set_Vel_Gains', {'Vel_Integrator_Gain':0.166, 'Vel_Gain':0.125})
msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
bus.send(msg)

msg = database.get_message_by_name('Axis0_Set_Pos_Gain')
data = database.encode_message('Axis0_Set_Pos_Gain', {'Pos_Gain':5.0})
msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
bus.send(msg)


try:
#  config closeloop first
    while True:

        msg = database.get_message_by_name('Axis0_Set_Input_Pos')
# step1.'Input_Pos': 1 = 1 round, step2. Input_Pos': 0 = again
        data = database.encode_message('Axis0_Set_Input_Pos', {'Input_Pos':0/round, 'Vel_FF':0.0, 'Torque_FF':0.0})
        msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
        print(database.decode_message('Axis0_Set_Input_Pos', msg.data))
        print(msg)

        bus.send(msg)
        time.sleep(0.16)
    

        msg = database.get_message_by_name('Axis0_Set_Input_Pos')
# step1.'Input_Pos': 1 = 1 round, step2. Input_Pos': 0 = again
        data = database.encode_message('Axis0_Set_Input_Pos', {'Input_Pos':90/round, 'Vel_FF':0.0, 'Torque_FF':0.0})
        msg = can.Message(arbitration_id=msg.frame_id | axisID << 5, is_extended_id=False, data=data)
        print(database.decode_message('Axis0_Set_Input_Pos', msg.data))
        print(msg)

        bus.send(msg)
        time.sleep(0.16)



        print("Message sent on {}".format(bus.channel_info))
except can.CanError:
    print("Message NOT sent!  Please verify can0 is working first")
